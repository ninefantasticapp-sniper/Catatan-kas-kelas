import express, { Request, Response } from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { AppData, NotificationMessage, Student, Expense } from './src/types';
import { getInitialData } from './src/defaultData';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.resolve(__dirname, 'data');
const DATA_FILE = path.resolve(DATA_DIR, 'kas_data.json');

// Ensure data folder exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Load or initialize data
let appData: AppData;
if (fs.existsSync(DATA_FILE)) {
  try {
    const raw = fs.readFileSync(DATA_FILE, 'utf-8');
    appData = JSON.parse(raw);
  } catch (err) {
    console.error('Error reading kas_data.json, initializing fresh data:', err);
    appData = getInitialData();
    saveData();
  }
} else {
  appData = getInitialData();
  saveData();
}

function saveData() {
  try {
    appData.lastUpdated = Date.now();
    fs.writeFileSync(DATA_FILE, JSON.stringify(appData, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to save data file:', err);
  }
}

// SSE Clients for realtime updates
interface SSEClient {
  id: string;
  res: Response;
  studentId?: string;
}

let sseClients: SSEClient[] = [];

function broadcast(eventType: string, payload: unknown) {
  const dataString = `event: ${eventType}\ndata: ${JSON.stringify(payload)}\n\n`;
  sseClients.forEach((client) => {
    try {
      client.res.write(dataString);
    } catch {
      // client likely disconnected
    }
  });
}

function broadcastNotification(notif: NotificationMessage) {
  // Broadcast to all clients or specific student
  sseClients.forEach((client) => {
    try {
      const isTarget = notif.targetStudentId === 'all' || client.studentId === notif.targetStudentId;
      if (isTarget) {
        client.res.write(`event: notification\ndata: ${JSON.stringify(notif)}\n\n`);
      }
    } catch {
      // ignore
    }
  });
}

// Middleware
app.use(express.json());

// API Routes
app.get('/api/data', (_req: Request, res: Response) => {
  res.json(appData);
});

// Realtime SSE endpoint
app.get('/api/realtime', (req: Request, res: Response) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();

  const clientId = `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
  const studentId = (req.query.studentId as string) || undefined;

  const client: SSEClient = { id: clientId, res, studentId };
  sseClients.push(client);

  // Send initial ping and current state
  res.write(`event: connected\ndata: ${JSON.stringify({ clientId, timestamp: Date.now() })}\n\n`);

  req.on('close', () => {
    sseClients = sseClients.filter((c) => c.id !== clientId);
  });
});

// Update settings (Nominal Kas per session & PIN Admin)
app.post('/api/settings', (req: Request, res: Response) => {
  const { nominalPerSession, adminPin } = req.body;
  if (typeof nominalPerSession === 'number' && nominalPerSession >= 0) {
    appData.nominalPerSession = nominalPerSession;
  }
  if (typeof adminPin === 'string' && adminPin.trim().length >= 4) {
    appData.adminPin = adminPin.trim();
  }
  saveData();
  broadcast('update', appData);
  res.json({ success: true, appData });
});

// Student management
app.post('/api/students', (req: Request, res: Response) => {
  const { name, absen } = req.body;
  if (!name || typeof absen !== 'number') {
    return res.status(400).json({ error: 'Nama dan Nomor Absen wajib diisi' });
  }

  const newStudent: Student = {
    id: `std-${Date.now()}`,
    name: name.trim().toUpperCase(),
    absen
  };

  appData.students.push(newStudent);
  // Sort students by absen
  appData.students.sort((a, b) => a.absen - b.absen);

  // Initialize payment record
  if (!appData.payments[newStudent.id]) {
    appData.payments[newStudent.id] = {};
    appData.weeks.forEach((w) => {
      appData.payments[newStudent.id][w.id] = { rabu: false, kamis: false };
    });
  }

  saveData();
  broadcast('update', appData);
  res.json({ success: true, student: newStudent, appData });
});

app.put('/api/students/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const { name, absen } = req.body;
  const student = appData.students.find((s) => s.id === id);
  if (!student) {
    return res.status(404).json({ error: 'Siswa tidak ditemukan' });
  }

  if (name) student.name = name.trim().toUpperCase();
  if (typeof absen === 'number') student.absen = absen;

  appData.students.sort((a, b) => a.absen - b.absen);
  saveData();
  broadcast('update', appData);
  res.json({ success: true, student, appData });
});

app.delete('/api/students/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  appData.students = appData.students.filter((s) => s.id !== id);
  delete appData.payments[id];
  saveData();
  broadcast('update', appData);
  res.json({ success: true, appData });
});

// Payments checklist toggle
app.post('/api/payments', (req: Request, res: Response) => {
  const { studentId, weekId, session, paid } = req.body;
  if (!studentId || !weekId || (session !== 'rabu' && session !== 'kamis')) {
    return res.status(400).json({ error: 'Parameter tidak valid' });
  }

  if (!appData.payments[studentId]) {
    appData.payments[studentId] = {};
  }
  if (!appData.payments[studentId][weekId]) {
    appData.payments[studentId][weekId] = { rabu: false, kamis: false };
  }

  const todayStr = new Date().toISOString().split('T')[0];
  appData.payments[studentId][weekId][session as 'rabu' | 'kamis'] = !!paid;
  if (paid) {
    if (session === 'rabu') appData.payments[studentId][weekId].rabuPaidAt = todayStr;
    if (session === 'kamis') appData.payments[studentId][weekId].kamisPaidAt = todayStr;
  }

  saveData();
  broadcast('update', appData);
  res.json({ success: true, appData });
});

// Bulk payment update (e.g. mark entire week paid for a student or mark everyone paid for a session)
app.post('/api/payments/bulk', (req: Request, res: Response) => {
  const { weekId, session, studentId, paid } = req.body;
  const todayStr = new Date().toISOString().split('T')[0];

  if (studentId && weekId) {
    // Mark both rabu and kamis for this student in this week
    if (!appData.payments[studentId]) appData.payments[studentId] = {};
    appData.payments[studentId][weekId] = {
      rabu: !!paid,
      kamis: !!paid,
      rabuPaidAt: paid ? todayStr : undefined,
      kamisPaidAt: paid ? todayStr : undefined
    };
  } else if (weekId && session) {
    // Mark all students for this session in this week
    appData.students.forEach((s) => {
      if (!appData.payments[s.id]) appData.payments[s.id] = {};
      if (!appData.payments[s.id][weekId]) {
        appData.payments[s.id][weekId] = { rabu: false, kamis: false };
      }
      appData.payments[s.id][weekId][session as 'rabu' | 'kamis'] = !!paid;
      if (paid) {
        if (session === 'rabu') appData.payments[s.id][weekId].rabuPaidAt = todayStr;
        if (session === 'kamis') appData.payments[s.id][weekId].kamisPaidAt = todayStr;
      }
    });
  }

  saveData();
  broadcast('update', appData);
  res.json({ success: true, appData });
});

// Weeks management
app.post('/api/weeks', (req: Request, res: Response) => {
  const { label } = req.body;
  if (!label) return res.status(400).json({ error: 'Nama minggu wajib diisi' });

  const newWeek = {
    id: `w${appData.weeks.length + 1}-${Date.now().toString(36)}`,
    label: label.trim()
  };

  appData.weeks.push(newWeek);
  // Initialize student payments for this week
  appData.students.forEach((s) => {
    if (!appData.payments[s.id]) appData.payments[s.id] = {};
    appData.payments[s.id][newWeek.id] = { rabu: false, kamis: false };
  });

  saveData();
  broadcast('update', appData);
  res.json({ success: true, week: newWeek, appData });
});

app.delete('/api/weeks/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  if (appData.weeks.length <= 1) {
    return res.status(400).json({ error: 'Minimal harus ada 1 minggu kas' });
  }

  appData.weeks = appData.weeks.filter((w) => w.id !== id);
  appData.students.forEach((s) => {
    if (appData.payments[s.id]) {
      delete appData.payments[s.id][id];
    }
  });

  saveData();
  broadcast('update', appData);
  res.json({ success: true, appData });
});

// Expenses management
app.post('/api/expenses', (req: Request, res: Response) => {
  const { date, title, amount, category, note } = req.body;
  if (!title || typeof amount !== 'number' || amount <= 0) {
    return res.status(400).json({ error: 'Judul dan nominal belanja valid wajib diisi' });
  }

  const newExpense: Expense = {
    id: `exp-${Date.now()}`,
    date: date || new Date().toISOString().split('T')[0],
    title: title.trim(),
    amount,
    category: category || 'Lainnya',
    note: note?.trim(),
    createdAt: Date.now()
  };

  appData.expenses.unshift(newExpense);
  saveData();
  broadcast('update', appData);
  res.json({ success: true, expense: newExpense, appData });
});

app.delete('/api/expenses/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  appData.expenses = appData.expenses.filter((e) => e.id !== id);
  saveData();
  broadcast('update', appData);
  res.json({ success: true, appData });
});

// Notifications
app.post('/api/notifications', (req: Request, res: Response) => {
  const { targetStudentId, title, message } = req.body;
  if (!message || !message.trim()) {
    return res.status(400).json({ error: 'Pesan notifikasi tidak boleh kosong' });
  }

  let targetStudentName = 'Semua Siswa';
  if (targetStudentId && targetStudentId !== 'all') {
    const student = appData.students.find((s) => s.id === targetStudentId);
    if (student) targetStudentName = student.name;
  }

  const newNotif: NotificationMessage = {
    id: `notif-${Date.now()}`,
    targetStudentId: targetStudentId || 'all',
    targetStudentName,
    title: title?.trim() || 'Kas Kelas',
    message: message.trim(),
    createdAt: Date.now(),
    readBy: []
  };

  appData.notifications.unshift(newNotif);
  // Keep only latest 100 notifications
  if (appData.notifications.length > 100) {
    appData.notifications = appData.notifications.slice(0, 100);
  }

  saveData();
  broadcast('update', appData);
  broadcastNotification(newNotif);

  res.json({ success: true, notification: newNotif, appData });
});

// Mark notification as read
app.post('/api/notifications/read', (req: Request, res: Response) => {
  const { notificationId, studentId } = req.body;
  const notif = appData.notifications.find((n) => n.id === notificationId);
  if (notif && studentId) {
    if (!notif.readBy) notif.readBy = [];
    if (!notif.readBy.includes(studentId)) {
      notif.readBy.push(studentId);
      saveData();
      broadcast('update', appData);
    }
  }
  res.json({ success: true });
});

// Reset data back to default initial state
app.post('/api/reset', (_req: Request, res: Response) => {
  appData = getInitialData();
  saveData();
  broadcast('update', appData);
  res.json({ success: true, appData });
});

// Start Express server and mount Vite or Static assets
async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR !== 'true',
        watch: process.env.DISABLE_HMR === 'true' ? null : {}
      },
      appType: 'spa'
    });

    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`Server Kas Kelas running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
