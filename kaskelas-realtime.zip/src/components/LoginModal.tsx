import React, { useState } from 'react';
import { User, ShieldCheck, KeyRound, Search, CheckCircle2, AlertCircle, X, Sparkles } from 'lucide-react';
import { Student } from '../types';
import { requestNotificationPermission } from '../utils/notifications';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultRole: 'student' | 'admin';
  students: Student[];
  adminPin: string;
  onLoginStudent: (student: Student) => void;
  onLoginAdmin: () => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({
  isOpen,
  onClose,
  defaultRole,
  students,
  adminPin,
  onLoginStudent,
  onLoginAdmin
}) => {
  const [tab, setTab] = useState<'student' | 'admin'>(defaultRole);

  // Student login fields
  const [selectedStudentId, setSelectedStudentId] = useState<string>('');
  const [searchName, setSearchName] = useState('');
  const [inputAbsen, setInputAbsen] = useState('');
  const [studentError, setStudentError] = useState('');

  // Admin login fields
  const [pinInput, setPinInput] = useState('');
  const [adminError, setAdminError] = useState('');

  React.useEffect(() => {
    setTab(defaultRole);
    setStudentError('');
    setAdminError('');
    setPinInput('');
  }, [defaultRole, isOpen]);

  if (!isOpen) return null;

  // Filter students based on typed search query
  const filteredStudents = students.filter(
    (s) =>
      s.name.toLowerCase().includes(searchName.toLowerCase()) ||
      String(s.absen).includes(searchName)
  );

  const handleSelectStudent = (student: Student) => {
    setSelectedStudentId(student.id);
    setSearchName(student.name);
    setInputAbsen(String(student.absen));
    setStudentError('');
  };

  const handleStudentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStudentError('');

    let matchedStudent: Student | undefined;

    if (selectedStudentId) {
      matchedStudent = students.find((s) => s.id === selectedStudentId);
    } else {
      const cleanName = searchName.trim().toUpperCase();
      const numAbsen = parseInt(inputAbsen.trim(), 10);
      matchedStudent = students.find(
        (s) => s.name.toUpperCase() === cleanName && s.absen === numAbsen
      );
    }

    if (!matchedStudent) {
      setStudentError('Nama Lengkap atau Nomor Absen tidak cocok dengan data 31 siswa.');
      return;
    }

    // Verify Absen matches
    if (parseInt(inputAbsen, 10) !== matchedStudent.absen) {
      setStudentError(`Nomor Absen tidak cocok untuk ${matchedStudent.name}.`);
      return;
    }

    // Prompt Web Notification permission as instructed
    await requestNotificationPermission().catch(() => {});

    onLoginStudent(matchedStudent);
    onClose();
  };

  const handleAdminSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setAdminError('');

    if (pinInput.trim() === adminPin.trim()) {
      onLoginAdmin();
      onClose();
    } else {
      setAdminError('PIN Bendahara salah! Gunakan PIN yang sesuai (default: 1234).');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-4 animate-fade-in">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl overflow-hidden border border-slate-100">
        {/* Header Tabs */}
        <div className="relative bg-gradient-to-r from-teal-800 to-teal-900 text-white p-5 pb-3">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-teal-200 hover:text-white p-1 rounded-lg hover:bg-white/10 transition"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2 mb-3">
            <Sparkles className="w-5 h-5 text-amber-300" />
            <h2 className="text-lg font-bold">Masuk ke Sistem Kas Kelas</h2>
          </div>

          <div className="flex bg-teal-950/40 p-1 rounded-xl">
            <button
              onClick={() => {
                setTab('student');
                setStudentError('');
              }}
              className={`flex-1 py-2 text-xs font-bold rounded-lg flex items-center justify-center gap-2 transition ${
                tab === 'student'
                  ? 'bg-white text-teal-900 shadow-sm'
                  : 'text-teal-200 hover:text-white'
              }`}
            >
              <User className="w-4 h-4" />
              Login Siswa
            </button>
            <button
              onClick={() => {
                setTab('admin');
                setAdminError('');
              }}
              className={`flex-1 py-2 text-xs font-bold rounded-lg flex items-center justify-center gap-2 transition ${
                tab === 'admin'
                  ? 'bg-amber-400 text-teal-950 shadow-sm'
                  : 'text-teal-200 hover:text-white'
              }`}
            >
              <ShieldCheck className="w-4 h-4" />
              Login Bendahara
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-5">
          {tab === 'student' ? (
            <form onSubmit={handleStudentSubmit} className="space-y-4">
              <div className="bg-teal-50 border border-teal-200 rounded-xl p-3 text-xs text-teal-800">
                Pilih atau cari namamu dari daftar 31 siswa, lalu pastikan nomor absen sesuai.
              </div>

              {studentError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{studentError}</span>
                </div>
              )}

              {/* Student Name Selector / Autocomplete */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Nama Lengkap Siswa
                </label>
                <div className="relative">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    value={searchName}
                    onChange={(e) => {
                      setSearchName(e.target.value);
                      setSelectedStudentId('');
                    }}
                    placeholder="Ketik atau cari nama kamu..."
                    className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-600 bg-white"
                    required
                  />
                </div>

                {/* Dropdown suggestions when typing or empty */}
                {searchName && !selectedStudentId && filteredStudents.length > 0 && (
                  <div className="mt-1 max-h-40 overflow-y-auto border border-slate-200 rounded-xl bg-white shadow-lg divide-y divide-slate-100 z-10 text-xs">
                    {filteredStudents.slice(0, 6).map((std) => (
                      <button
                        type="button"
                        key={std.id}
                        onClick={() => handleSelectStudent(std)}
                        className="w-full px-3 py-2 text-left hover:bg-teal-50 flex items-center justify-between transition"
                      >
                        <span className="font-medium text-slate-800">{std.name}</span>
                        <span className="bg-teal-100 text-teal-800 font-bold px-1.5 py-0.5 rounded text-[10px]">
                          Absen #{std.absen}
                        </span>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Absen Number Input */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Nomor Absen
                </label>
                <input
                  type="number"
                  min="1"
                  max="100"
                  value={inputAbsen}
                  onChange={(e) => setInputAbsen(e.target.value)}
                  placeholder="Contoh: 21"
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-600 bg-white"
                  required
                />
              </div>

              {/* Quick sample student buttons */}
              <div>
                <p className="text-[11px] text-slate-500 mb-1.5">Pilihan Cepat Uji Coba:</p>
                <div className="flex flex-wrap gap-1.5">
                  {students.slice(0, 3).map((std) => (
                    <button
                      type="button"
                      key={std.id}
                      onClick={() => handleSelectStudent(std)}
                      className="px-2 py-1 text-[11px] bg-slate-100 hover:bg-teal-100 hover:text-teal-900 text-slate-700 rounded-lg transition"
                    >
                      #{std.absen} {std.name.split(' ')[0]}
                    </button>
                  ))}
                  {students.find((s) => s.absen === 21) && (
                    <button
                      type="button"
                      onClick={() => {
                        const caesar = students.find((s) => s.absen === 21);
                        if (caesar) handleSelectStudent(caesar);
                      }}
                      className="px-2 py-1 text-[11px] bg-amber-100 text-amber-900 font-semibold rounded-lg hover:bg-amber-200 transition"
                    >
                      #21 M. CAESAR
                    </button>
                  )}
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-teal-700 hover:bg-teal-800 text-white font-bold rounded-xl shadow-md transition flex items-center justify-center gap-2 text-sm"
              >
                <CheckCircle2 className="w-4 h-4" />
                Masuk Dashboard Siswa
              </button>
            </form>
          ) : (
            <form onSubmit={handleAdminSubmit} className="space-y-4">
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 text-xs text-amber-900">
                Akses khusus Bendahara Kelas. Masukkan PIN keamanan untuk mengelola kas, checklist, dan kirim notifikasi.
                <p className="mt-1 font-semibold text-amber-800">Default PIN: 1234</p>
              </div>

              {adminError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{adminError}</span>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  PIN Keamanan Bendahara
                </label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="password"
                    value={pinInput}
                    onChange={(e) => setPinInput(e.target.value)}
                    placeholder="Masukkan 4 digit PIN..."
                    className="w-full pl-9 pr-3 py-2 text-sm tracking-widest border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 bg-white"
                    required
                    autoFocus
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-amber-500 hover:bg-amber-600 text-teal-950 font-bold rounded-xl shadow-md transition flex items-center justify-center gap-2 text-sm"
              >
                <ShieldCheck className="w-4 h-4" />
                Buka Panel Bendahara
              </button>

              <p className="text-center text-[11px] text-slate-400">
                PIN dapat diubah kapan saja di menu Pengaturan Bendahara
              </p>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
