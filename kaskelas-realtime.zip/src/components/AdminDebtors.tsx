import React, { useState } from 'react';
import { 
  AlertTriangle, 
  Send, 
  Copy, 
  Check, 
  Download, 
  Search, 
  CheckCircle2,
  Share2,
  Calendar
} from 'lucide-react';
import { AppData, Student } from '../types';
import { formatRupiah, calculateSummary, getStudentStatus } from '../utils/format';

interface AdminDebtorsProps {
  data: AppData;
  onPrepareNotification: (targetStudentId: string, prefilledMessage: string) => void;
}

export const AdminDebtors: React.FC<AdminDebtorsProps> = ({ data, onPrepareNotification }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [copied, setCopied] = useState(false);

  const summary = calculateSummary(data);

  const filteredDebtors = summary.debtors.filter(
    (d) =>
      d.student.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      String(d.student.absen).includes(searchQuery)
  );

  const totalOutstanding = summary.debtors.reduce((sum, d) => sum + d.totalDebt, 0);

  // Copy WhatsApp format recap to clipboard
  const handleCopyWhatsApp = () => {
    let text = `📢 *REKAP TUNGGAKAN KAS KELAS*\n`;
    text += `Total Penunggak: ${summary.debtors.length} Siswa\n`;
    text += `Total Belum Terbayar: ${formatRupiah(totalOutstanding)}\n`;
    text += `Nominal per Sesi: ${formatRupiah(data.nominalPerSession)} (Rabu & Kamis)\n\n`;

    summary.debtors.forEach((d, idx) => {
      const sessionsText = d.unpaidSessions.map((s) => s.sessionLabel).join(', ');
      text += `${idx + 1}. *#${d.student.absen} ${d.student.name}*\n`;
      text += `   - Total: *${formatRupiah(d.totalDebt)}*\n`;
      text += `   - Belum Bayar: ${sessionsText}\n\n`;
    });

    text += `Mohon segera melunasi ke Bendahara saat hari penarikan Rabu / Kamis. Terima kasih!`;

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleExportCSV = () => {
    let csv = 'No Absen,Nama Siswa,Sesi Belum Bayar,Total Tunggakan (Rp)\n';
    summary.debtors.forEach((d) => {
      const sessionsText = d.unpaidSessions.map((s) => s.sessionLabel).join('; ');
      csv += `"${d.student.absen}","${d.student.name}","${sessionsText}","${d.totalDebt}"\n`;
    });

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `rekap_penunggak_kas_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-xs border border-slate-200 space-y-4">
      {/* Top Banner Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-rose-50 border border-rose-200 p-4 rounded-xl">
          <span className="text-[11px] font-bold text-rose-800 uppercase tracking-wide">
            Total Tunggakan Kas
          </span>
          <div className="text-lg sm:text-xl font-black text-rose-700 mt-0.5">
            {formatRupiah(totalOutstanding)}
          </div>
          <span className="text-[11px] text-rose-600">Dari {summary.debtors.length} siswa</span>
        </div>

        <div className="bg-emerald-50 border border-emerald-200 p-4 rounded-xl">
          <span className="text-[11px] font-bold text-emerald-800 uppercase tracking-wide">
            Siswa Sudah Lunas
          </span>
          <div className="text-lg sm:text-xl font-black text-emerald-700 mt-0.5">
            {summary.lunasCount} Siswa
          </div>
          <span className="text-[11px] text-emerald-600">
            {((summary.lunasCount / data.students.length) * 100).toFixed(0)}% dari total kelas
          </span>
        </div>

        <div className="bg-teal-50 border border-teal-200 p-4 rounded-xl">
          <span className="text-[11px] font-bold text-teal-800 uppercase tracking-wide">
            Sistem Penarikan
          </span>
          <div className="text-sm font-black text-teal-900 mt-0.5">
            Rabu & Kamis
          </div>
          <span className="text-[11px] text-teal-700">
            {formatRupiah(data.nominalPerSession)} per sesi bayar
          </span>
        </div>
      </div>

      {/* Action Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
        <div className="relative flex-1 sm:max-w-xs">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cari penunggak..."
            className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-rose-500 bg-white"
          />
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          <button
            onClick={handleCopyWhatsApp}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition"
          >
            {copied ? <Check className="w-3.5 h-3.5" /> : <Share2 className="w-3.5 h-3.5" />}
            <span>{copied ? 'Tersalin ke Clipboard!' : 'Salin Format WhatsApp'}</span>
          </button>

          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200 transition"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Debtors List Table */}
      {filteredDebtors.length === 0 ? (
        <div className="text-center py-10 text-slate-400 text-xs bg-slate-50 rounded-xl border border-slate-200">
          <CheckCircle2 className="w-8 h-8 mx-auto text-emerald-500 mb-2" />
          <p className="font-bold text-slate-700 text-sm">Hebat! Tidak Ada Penunggak Kas</p>
          <p className="text-slate-500 mt-0.5">Semua siswa telah melunasi kas kelas untuk semua minggu.</p>
        </div>
      ) : (
        <div className="overflow-x-auto border border-slate-200 rounded-xl shadow-xs">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-3 text-center w-12">Absen</th>
                <th className="py-2.5 px-3">Nama Siswa</th>
                <th className="py-2.5 px-3">Detail Sesi yang Belum Dibayar</th>
                <th className="py-2.5 px-3 text-right">Total Kekurangan</th>
                <th className="py-2.5 px-3 text-center w-36">Aksi Penagihan</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredDebtors.map((item) => {
                const unpaidText = item.unpaidSessions
                  .map((s) => s.sessionLabel)
                  .join(', ');

                return (
                  <tr key={item.student.id} className="hover:bg-rose-50/20 transition">
                    <td className="py-2.5 px-3 text-center font-bold text-slate-500">
                      #{item.student.absen}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="font-semibold text-slate-800">{item.student.name}</span>
                    </td>
                    <td className="py-2.5 px-3">
                      <div className="flex flex-wrap gap-1">
                        {item.unpaidSessions.map((session, sIdx) => (
                          <span
                            key={sIdx}
                            className="inline-block px-2 py-0.5 rounded-md bg-rose-100 text-rose-800 font-medium text-[10px]"
                          >
                            {session.sessionLabel}
                          </span>
                        ))}
                      </div>
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      <span className="font-black text-rose-700 text-xs sm:text-sm">
                        {formatRupiah(item.totalDebt)}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-center">
                      <button
                        onClick={() => {
                          const message = `Halo ${item.student.name} (Absen #${item.student.absen}), kamu memiliki tunggakan kas kelas sebesar ${formatRupiah(item.totalDebt)} untuk sesi: ${unpaidText}. Mohon segera melunasi pada jadwal penarikan kas hari Rabu/Kamis ya. Terima kasih!`;
                          onPrepareNotification(item.student.id, message);
                        }}
                        className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-teal-700 hover:bg-teal-800 text-white font-bold text-[11px] shadow-xs transition"
                        title="Kirim pesan notifikasi penagihan ke HP siswa ini"
                      >
                        <Send className="w-3 h-3" />
                        <span>Tagih via Notif</span>
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
