import React, { useState } from 'react';
import { 
  CheckCircle, 
  AlertTriangle, 
  Coins, 
  TrendingUp, 
  TrendingDown, 
  Bell, 
  Calendar, 
  FileText, 
  Users, 
  Search, 
  Volume2, 
  Smartphone,
  Check,
  XCircle,
  Clock,
  Sparkles
} from 'lucide-react';
import { AppData, Student, NotificationMessage } from '../types';
import { formatRupiah, formatDateIndo, formatTimeIndo, getStudentStatus, calculateSummary } from '../utils/format';
import { triggerSystemNotification, requestNotificationPermission, getNotificationPermission } from '../utils/notifications';
import { apiMarkNotificationRead } from '../api';

interface StudentDashboardProps {
  student: Student;
  data: AppData;
  onLogout: () => void;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({ student, data }) => {
  const [activeTab, setActiveTab] = useState<'status' | 'transparency' | 'expenses' | 'notifications'>('status');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedWeekFilter, setSelectedWeekFilter] = useState<string>('all');
  const [notifPermission, setNotifPermission] = useState<NotificationPermission>('default');
  const [testNotifSent, setTestNotifSent] = useState(false);

  React.useEffect(() => {
    setNotifPermission(getNotificationPermission());
  }, []);

  const studentStatus = getStudentStatus(student, data);
  const summary = calculateSummary(data);

  // Filter notifications for this student (all or targeted to them)
  const myNotifications = data.notifications.filter(
    (n) => n.targetStudentId === 'all' || n.targetStudentId === student.id
  );

  const handleRequestPermission = async () => {
    const perm = await requestNotificationPermission();
    setNotifPermission(perm);
  };

  const handleTestSystemNotification = async () => {
    setTestNotifSent(true);
    await triggerSystemNotification(
      `Kas Kelas - ${student.name}`,
      `Halo Absen #${student.absen}! Uji coba notifikasi bilah status HP berhasil. Kamu akan menerima notifikasi tagihan atau pengumuman di sini.`,
      window.location.href
    );
    setTimeout(() => setTestNotifSent(false), 3000);
  };

  // Filter class students for transparency table
  const filteredClass = data.students.filter(
    (s) =>
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      String(s.absen).includes(searchQuery)
  );

  return (
    <div className="space-y-4 pb-12">
      {/* Top Welcome & Notification Banner */}
      <div className="bg-gradient-to-r from-teal-800 to-teal-950 text-white rounded-2xl p-4 sm:p-6 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 translate-x-6 -translate-y-6 w-40 h-40 bg-white/5 rounded-full blur-xl pointer-events-none" />

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-teal-700/60 text-teal-200 text-xs font-medium mb-2 border border-teal-600/40">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              Siswa Terautentikasi
            </div>
            <h2 className="text-xl sm:text-2xl font-black tracking-tight">{student.name}</h2>
            <p className="text-xs sm:text-sm text-teal-200 mt-0.5">
              Nomor Absen: <strong className="text-white font-bold">#{student.absen}</strong> &bull; Jadwal Kas: Setiap <span className="text-amber-300 font-semibold">Rabu</span> & <span className="text-amber-300 font-semibold">Kamis</span>
            </p>
          </div>

          {/* Quick Notification State Pill & Test Button */}
          <div className="flex flex-wrap items-center gap-2">
            {notifPermission === 'granted' ? (
              <button
                onClick={handleTestSystemNotification}
                disabled={testNotifSent}
                className="flex items-center gap-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-xl shadow-sm transition active:scale-95"
                title="Kirim uji coba notifikasi bilah HP sekarang"
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>{testNotifSent ? 'Terkirim ke Bilah HP!' : 'Uji Notif Bilah HP'}</span>
              </button>
            ) : (
              <button
                onClick={handleRequestPermission}
                className="flex items-center gap-1.5 px-3 py-2 bg-amber-400 hover:bg-amber-300 text-teal-950 text-xs font-bold rounded-xl shadow-md transition animate-pulse"
              >
                <Bell className="w-3.5 h-3.5" />
                <span>Aktifkan Notif Bilah HP</span>
              </button>
            )}
          </div>
        </div>

        {/* Informative Notification banner if not granted yet */}
        {notifPermission !== 'granted' && (
          <div className="mt-4 p-3 bg-teal-900/90 border border-teal-700/80 rounded-xl text-xs text-teal-100 flex items-start gap-2.5">
            <Volume2 className="w-4 h-4 text-amber-300 shrink-0 mt-0.5" />
            <div className="flex-1">
              <span className="font-semibold text-white">Notifikasi Bilah Status HP belum aktif:</span> Tekan tombol di atas agar pesan tagihan dan pengingat dari Bendahara langsung muncul di bilah status HP kamu.
            </div>
          </div>
        )}
      </div>

      {/* Primary Status Card: Lunas vs Menunggak */}
      <div
        className={`rounded-2xl p-4 sm:p-5 shadow-sm border ${
          studentStatus.isLunas
            ? 'bg-emerald-50/80 border-emerald-200 text-emerald-900'
            : 'bg-rose-50/90 border-rose-200 text-rose-950'
        }`}
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <div
              className={`w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 ${
                studentStatus.isLunas
                  ? 'bg-emerald-500 text-white shadow-md shadow-emerald-500/20'
                  : 'bg-rose-500 text-white shadow-md shadow-rose-500/20 animate-bounce'
              }`}
            >
              {studentStatus.isLunas ? (
                <CheckCircle className="w-6 h-6" />
              ) : (
                <AlertTriangle className="w-6 h-6" />
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold tracking-wide uppercase text-slate-500">
                  Status Kas Pribadi
                </span>
                <span
                  className={`text-xs font-black px-2.5 py-0.5 rounded-full ${
                    studentStatus.isLunas
                      ? 'bg-emerald-600 text-white'
                      : 'bg-rose-600 text-white'
                  }`}
                >
                  {studentStatus.isLunas ? 'LUNAS' : 'KURANG BAYAR / MENUNGGAK'}
                </span>
              </div>
              <p className="text-base sm:text-lg font-bold mt-1">
                {studentStatus.isLunas
                  ? 'Alhamdulillah, pembayaran kas kamu sudah lengkap!'
                  : `Kamu memiliki kekurangan kas sebesar ${formatRupiah(studentStatus.totalDebt)}`}
              </p>
            </div>
          </div>

          <div className="text-right sm:self-center">
            <div className="text-xs text-slate-500">Tercatat Membayar</div>
            <div className="text-sm sm:text-base font-extrabold text-slate-800">
              {studentStatus.paidSessionsCount} / {studentStatus.totalSessionsCount} Sesi
            </div>
          </div>
        </div>

        {/* Detailed unpaid sessions list if debtor */}
        {!studentStatus.isLunas && (
          <div className="mt-4 pt-4 border-t border-rose-200/80">
            <h4 className="text-xs font-bold text-rose-900 mb-2 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-rose-600" />
              Detail Sesi yang Belum Dibayar ({studentStatus.unpaidSessions.length} Sesi):
            </h4>
            <div className="flex flex-wrap gap-1.5">
              {studentStatus.unpaidSessions.map((session, idx) => (
                <span
                  key={idx}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-rose-200/70 text-rose-900 font-semibold text-xs border border-rose-300"
                >
                  <XCircle className="w-3.5 h-3.5 text-rose-700" />
                  {session.sessionLabel} ({formatRupiah(data.nominalPerSession)})
                </span>
              ))}
            </div>
            <p className="text-[11px] text-rose-700 mt-2">
              Mohon segera melunasi ke Bendahara Kelas pada hari Rabu atau Kamis saat penarikan kas.
            </p>
          </div>
        )}
      </div>

      {/* Class Financial Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-white p-4 rounded-2xl shadow-xs border border-slate-200 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center shrink-0">
            <Coins className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide">
              Saldo Kas Aktif
            </span>
            <div className="text-base sm:text-lg font-black text-teal-900">
              {formatRupiah(summary.activeBalance)}
            </div>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl shadow-xs border border-slate-200 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
            <TrendingUp className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide">
              Total Kas Masuk
            </span>
            <div className="text-base sm:text-lg font-black text-emerald-700">
              {formatRupiah(summary.totalIncome)}
            </div>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl shadow-xs border border-slate-200 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-700 flex items-center justify-center shrink-0">
            <TrendingDown className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide">
              Total Pengeluaran
            </span>
            <div className="text-base sm:text-lg font-black text-rose-700">
              {formatRupiah(summary.totalExpense)}
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-slate-200/80 p-1 rounded-xl flex gap-1 overflow-x-auto text-xs font-bold text-slate-600">
        <button
          onClick={() => setActiveTab('status')}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-lg whitespace-nowrap transition ${
            activeTab === 'status'
              ? 'bg-white text-teal-900 shadow-xs'
              : 'hover:text-slate-900'
          }`}
        >
          <Calendar className="w-3.5 h-3.5" />
          Riwayat Kas Saya
        </button>
        <button
          onClick={() => setActiveTab('transparency')}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-lg whitespace-nowrap transition ${
            activeTab === 'transparency'
              ? 'bg-white text-teal-900 shadow-xs'
              : 'hover:text-slate-900'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          Transparansi Kelas ({data.students.length})
        </button>
        <button
          onClick={() => setActiveTab('expenses')}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-lg whitespace-nowrap transition ${
            activeTab === 'expenses'
              ? 'bg-white text-teal-900 shadow-xs'
              : 'hover:text-slate-900'
          }`}
        >
          <FileText className="w-3.5 h-3.5" />
          Belanja Kelas ({data.expenses.length})
        </button>
        <button
          onClick={() => setActiveTab('notifications')}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-lg whitespace-nowrap transition relative ${
            activeTab === 'notifications'
              ? 'bg-white text-teal-900 shadow-xs'
              : 'hover:text-slate-900'
          }`}
        >
          <Bell className="w-3.5 h-3.5" />
          Pesan & Notif
          {myNotifications.length > 0 && (
            <span className="bg-teal-700 text-white text-[10px] font-bold px-1.5 py-0.2 rounded-full">
              {myNotifications.length}
            </span>
          )}
        </button>
      </div>

      {/* Tab 1: Riwayat Kas Saya */}
      {activeTab === 'status' && (
        <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-xs border border-slate-200">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-sm sm:text-base font-bold text-slate-800">
                Jadwal Penarikan Kas Pribadi
              </h3>
              <p className="text-xs text-slate-500">
                Nominal kas Rp {data.nominalPerSession.toLocaleString('id-ID')} per sesi (Rabu & Kamis)
              </p>
            </div>
          </div>

          <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden">
            {data.weeks.map((week) => {
              const weekData = data.payments[student.id]?.[week.id] || { rabu: false, kamis: false };
              const isWeekFull = weekData.rabu && weekData.kamis;

              return (
                <div key={week.id} className="p-3.5 sm:p-4 hover:bg-slate-50/50 transition">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-800 text-sm">{week.label}</span>
                        {isWeekFull ? (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                            Lunas Minggu Ini
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900">
                            Belum Lengkap
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-slate-400">Total Rp 4.000 / minggu</span>
                    </div>

                    {/* Rabu & Kamis pill indicators */}
                    <div className="flex items-center gap-2">
                      {/* Sesi Rabu */}
                      <div
                        className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border text-xs ${
                          weekData.rabu
                            ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                            : 'bg-rose-50 border-rose-200 text-rose-800'
                        }`}
                      >
                        {weekData.rabu ? (
                          <Check className="w-4 h-4 text-emerald-600" />
                        ) : (
                          <XCircle className="w-4 h-4 text-rose-500" />
                        )}
                        <div>
                          <div className="font-bold">Sesi Rabu</div>
                          <div className="text-[10px] text-slate-500">
                            {weekData.rabu ? 'Sudah Dibayar' : 'Belum Bayar'}
                          </div>
                        </div>
                      </div>

                      {/* Sesi Kamis */}
                      <div
                        className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border text-xs ${
                          weekData.kamis
                            ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                            : 'bg-rose-50 border-rose-200 text-rose-800'
                        }`}
                      >
                        {weekData.kamis ? (
                          <Check className="w-4 h-4 text-emerald-600" />
                        ) : (
                          <XCircle className="w-4 h-4 text-rose-500" />
                        )}
                        <div>
                          <div className="font-bold">Sesi Kamis</div>
                          <div className="text-[10px] text-slate-500">
                            {weekData.kamis ? 'Sudah Dibayar' : 'Belum Bayar'}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Tab 2: Transparansi Rekap Kelas */}
      {activeTab === 'transparency' && (
        <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-xs border border-slate-200">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
            <div>
              <h3 className="text-sm sm:text-base font-bold text-slate-800">
                Transparansi Pembayaran Seluruh Kelas
              </h3>
              <p className="text-xs text-slate-500">
                Terbuka dan jujur demi keterbukaan uang kas kelas bersama
              </p>
            </div>

            <div className="flex items-center gap-2">
              <div className="relative flex-1 sm:w-56">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Cari siswa atau absen..."
                  className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-600"
                />
              </div>

              <select
                value={selectedWeekFilter}
                onChange={(e) => setSelectedWeekFilter(e.target.value)}
                className="text-xs border border-slate-300 rounded-xl px-2.5 py-1.5 bg-white text-slate-700"
              >
                <option value="all">Semua Minggu</option>
                {data.weeks.map((w) => (
                  <option key={w.id} value={w.id}>
                    {w.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="overflow-x-auto border border-slate-200 rounded-xl">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                <tr>
                  <th className="py-2.5 px-3 text-center w-12">Absen</th>
                  <th className="py-2.5 px-3">Nama Siswa</th>
                  {selectedWeekFilter === 'all' ? (
                    <>
                      <th className="py-2.5 px-3 text-center">Status Keseluruhan</th>
                      <th className="py-2.5 px-3 text-right">Kekurangan</th>
                    </>
                  ) : (
                    <>
                      <th className="py-2.5 px-3 text-center">Rabu</th>
                      <th className="py-2.5 px-3 text-center">Kamis</th>
                      <th className="py-2.5 px-3 text-center">Status Minggu</th>
                    </>
                  )}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredClass.map((std) => {
                  const isCurrent = std.id === student.id;
                  const stat = getStudentStatus(std, data);

                  if (selectedWeekFilter === 'all') {
                    return (
                      <tr
                        key={std.id}
                        className={`hover:bg-slate-50 transition ${
                          isCurrent ? 'bg-teal-50/70 font-semibold text-teal-950' : ''
                        }`}
                      >
                        <td className="py-2 px-3 text-center text-slate-500 font-bold">
                          #{std.absen}
                        </td>
                        <td className="py-2 px-3">
                          <div className="flex items-center gap-1.5">
                            <span>{std.name}</span>
                            {isCurrent && (
                              <span className="text-[10px] bg-teal-700 text-white px-1.5 py-0.2 rounded font-bold">
                                Kamu
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="py-2 px-3 text-center">
                          {stat.isLunas ? (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                              Lunas
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800">
                              Kurang {stat.unpaidSessions.length} Sesi
                            </span>
                          )}
                        </td>
                        <td className="py-2 px-3 text-right font-medium">
                          {stat.isLunas ? (
                            <span className="text-emerald-700 font-bold">Rp 0</span>
                          ) : (
                            <span className="text-rose-700 font-bold">
                              {formatRupiah(stat.totalDebt)}
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  }

                  // Single week view
                  const wp = data.payments[std.id]?.[selectedWeekFilter] || {
                    rabu: false,
                    kamis: false
                  };
                  const weekLunas = wp.rabu && wp.kamis;

                  return (
                    <tr
                      key={std.id}
                      className={`hover:bg-slate-50 transition ${
                        isCurrent ? 'bg-teal-50/70 font-semibold text-teal-950' : ''
                      }`}
                    >
                      <td className="py-2 px-3 text-center text-slate-500 font-bold">
                        #{std.absen}
                      </td>
                      <td className="py-2 px-3">
                        <div className="flex items-center gap-1.5">
                          <span>{std.name}</span>
                          {isCurrent && (
                            <span className="text-[10px] bg-teal-700 text-white px-1.5 py-0.2 rounded font-bold">
                              Kamu
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="py-2 px-3 text-center">
                        {wp.rabu ? (
                          <span className="text-emerald-600 font-bold inline-flex items-center gap-1">
                            <Check className="w-3.5 h-3.5" /> Lunas
                          </span>
                        ) : (
                          <span className="text-rose-600 font-semibold inline-flex items-center gap-1">
                            <XCircle className="w-3.5 h-3.5" /> Belum
                          </span>
                        )}
                      </td>
                      <td className="py-2 px-3 text-center">
                        {wp.kamis ? (
                          <span className="text-emerald-600 font-bold inline-flex items-center gap-1">
                            <Check className="w-3.5 h-3.5" /> Lunas
                          </span>
                        ) : (
                          <span className="text-rose-600 font-semibold inline-flex items-center gap-1">
                            <XCircle className="w-3.5 h-3.5" /> Belum
                          </span>
                        )}
                      </td>
                      <td className="py-2 px-3 text-center">
                        {weekLunas ? (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                            Lunas
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800">
                            Kurang
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 3: Riwayat Catatan Belanja & Pengeluaran Kelas */}
      {activeTab === 'expenses' && (
        <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-xs border border-slate-200">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm sm:text-base font-bold text-slate-800">
                Catatan Pengeluaran & Belanja Kas
              </h3>
              <p className="text-xs text-slate-500">
                Daftar semua belanja keperluan kelas yang dibiayai kas bersama
              </p>
            </div>
            <div className="text-right">
              <span className="text-xs text-slate-500">Total Dibelanjakan</span>
              <div className="text-sm sm:text-base font-extrabold text-rose-700">
                {formatRupiah(summary.totalExpense)}
              </div>
            </div>
          </div>

          {data.expenses.length === 0 ? (
            <div className="text-center py-8 text-slate-400 text-xs">
              Belum ada catatan pengeluaran kas yang dibukukan.
            </div>
          ) : (
            <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden">
              {data.expenses.map((item) => (
                <div key={item.id} className="p-3.5 sm:p-4 hover:bg-slate-50 transition">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-800 text-sm">{item.title}</span>
                        <span className="px-2 py-0.5 text-[10px] font-semibold rounded-full bg-slate-100 text-slate-700">
                          {item.category}
                        </span>
                      </div>
                      {item.note && (
                        <p className="text-xs text-slate-600 mt-0.5">{item.note}</p>
                      )}
                      <span className="text-[11px] text-slate-400 mt-1 inline-block">
                        Tanggal: {formatDateIndo(item.date)}
                      </span>
                    </div>
                    <div className="text-right shrink-0">
                      <div className="text-sm sm:text-base font-black text-rose-600">
                        -{formatRupiah(item.amount)}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 4: Pesan & Notifikasi dari Bendahara */}
      {activeTab === 'notifications' && (
        <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-xs border border-slate-200">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm sm:text-base font-bold text-slate-800">
                Pesan & Notifikasi Masuk
              </h3>
              <p className="text-xs text-slate-500">
                Pemberitahuan, tagihan, dan pengumuman kas dari Bendahara
              </p>
            </div>
            <button
              onClick={handleTestSystemNotification}
              className="text-xs text-teal-700 hover:text-teal-900 font-semibold flex items-center gap-1 bg-teal-50 px-2.5 py-1.5 rounded-lg border border-teal-200"
            >
              <Smartphone className="w-3.5 h-3.5" />
              Tes Notif HP
            </button>
          </div>

          {myNotifications.length === 0 ? (
            <div className="text-center py-10 text-slate-400 text-xs">
              <Bell className="w-8 h-8 mx-auto mb-2 opacity-30" />
              Belum ada pesan notifikasi untuk akun kamu.
            </div>
          ) : (
            <div className="space-y-3">
              {myNotifications.map((msg) => {
                const isTargetPersonal = msg.targetStudentId === student.id;

                return (
                  <div
                    key={msg.id}
                    className={`p-4 rounded-xl border transition ${
                      isTargetPersonal
                        ? 'bg-amber-50/70 border-amber-200 text-amber-950'
                        : 'bg-slate-50 border-slate-200 text-slate-800'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-slate-900">{msg.title}</span>
                        {isTargetPersonal ? (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-200 text-amber-900">
                            Pesan Khusus Untukmu
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-200 text-slate-700">
                            Semua Siswa
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-slate-400 shrink-0">
                        {formatTimeIndo(msg.createdAt)}
                      </span>
                    </div>
                    <p className="text-xs sm:text-sm text-slate-700 mt-2 whitespace-pre-wrap leading-relaxed">
                      {msg.message}
                    </p>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
