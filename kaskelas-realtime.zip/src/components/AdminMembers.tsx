import React, { useState } from 'react';
import { UserPlus, Edit2, Trash2, Search, Check, X, Users, AlertCircle } from 'lucide-react';
import { AppData, Student } from '../types';
import { apiAddStudent, apiUpdateStudent, apiDeleteStudent } from '../api';

interface AdminMembersProps {
  data: AppData;
  onDataUpdated: (newData: AppData) => void;
}

export const AdminMembers: React.FC<AdminMembersProps> = ({ data, onDataUpdated }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Form states
  const [nameInput, setNameInput] = useState('');
  const [absenInput, setAbsenInput] = useState('');
  const [error, setError] = useState('');

  const filteredStudents = data.students.filter(
    (s) =>
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      String(s.absen).includes(searchQuery)
  );

  const handleStartAdd = () => {
    setIsAdding(true);
    setEditingId(null);
    setNameInput('');
    setAbsenInput(String(data.students.length + 1));
    setError('');
  };

  const handleStartEdit = (student: Student) => {
    setEditingId(student.id);
    setIsAdding(false);
    setNameInput(student.name);
    setAbsenInput(String(student.absen));
    setError('');
  };

  const handleSaveAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const parsedAbsen = parseInt(absenInput, 10);
    if (!nameInput.trim() || isNaN(parsedAbsen) || parsedAbsen <= 0) {
      setError('Nama lengkap dan nomor absen harus valid.');
      return;
    }

    try {
      const updated = await apiAddStudent(nameInput.trim(), parsedAbsen);
      onDataUpdated(updated);
      setIsAdding(false);
      setNameInput('');
      setAbsenInput('');
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Gagal menambah siswa');
    }
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingId) return;
    setError('');

    const parsedAbsen = parseInt(absenInput, 10);
    if (!nameInput.trim() || isNaN(parsedAbsen) || parsedAbsen <= 0) {
      setError('Nama lengkap dan nomor absen harus valid.');
      return;
    }

    try {
      const updated = await apiUpdateStudent(editingId, nameInput.trim(), parsedAbsen);
      onDataUpdated(updated);
      setEditingId(null);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Gagal memperbarui siswa');
    }
  };

  const handleDelete = async (student: Student) => {
    if (!confirm(`Hapus ${student.name} (Absen #${student.absen}) dari anggota kas kelas?`)) return;
    try {
      const updated = await apiDeleteStudent(student.id);
      onDataUpdated(updated);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-xs border border-slate-200 space-y-4">
      {/* Header & Add Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
        <div>
          <h3 className="font-bold text-slate-800 text-sm sm:text-base flex items-center gap-2">
            <Users className="w-5 h-5 text-teal-700" />
            Manajemen Anggota Kelas ({data.students.length} Siswa)
          </h3>
          <p className="text-xs text-slate-500">
            Kelola nama dan nomor absen 31 siswa awal atau tambah anggota baru
          </p>
        </div>

        <button
          onClick={handleStartAdd}
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-teal-700 hover:bg-teal-800 text-white shadow-xs transition shrink-0"
        >
          <UserPlus className="w-4 h-4" />
          <span>Tambah Siswa Baru</span>
        </button>
      </div>

      {error && (
        <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-xl flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Add Student Inline Form */}
      {isAdding && (
        <form onSubmit={handleSaveAdd} className="p-4 bg-teal-50 border border-teal-200 rounded-xl space-y-3 animate-fade-in">
          <div className="flex items-center justify-between">
            <h4 className="font-bold text-xs text-teal-900">Form Tambah Siswa Baru</h4>
            <button
              type="button"
              onClick={() => setIsAdding(false)}
              className="text-slate-400 hover:text-slate-600"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-2 text-xs">
            <div className="sm:col-span-1">
              <label className="block font-semibold text-slate-700 mb-1">Nomor Absen</label>
              <input
                type="number"
                min="1"
                value={absenInput}
                onChange={(e) => setAbsenInput(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white"
                required
              />
            </div>
            <div className="sm:col-span-3">
              <label className="block font-semibold text-slate-700 mb-1">Nama Lengkap Siswa</label>
              <input
                type="text"
                value={nameInput}
                onChange={(e) => setNameInput(e.target.value)}
                placeholder="NAMA LENGKAP SISWA..."
                className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white uppercase"
                required
                autoFocus
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-1">
            <button
              type="button"
              onClick={() => setIsAdding(false)}
              className="px-3 py-1.5 text-xs font-semibold text-slate-600 hover:text-slate-800"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 bg-teal-700 text-white font-bold text-xs rounded-lg hover:bg-teal-800"
            >
              Simpan Siswa
            </button>
          </div>
        </form>
      )}

      {/* Search Input */}
      <div className="relative max-w-sm">
        <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Cari siswa berdasarkan nama atau absen..."
          className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-600 bg-white"
        />
      </div>

      {/* Members Table */}
      <div className="overflow-x-auto border border-slate-200 rounded-xl shadow-xs">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
            <tr>
              <th className="py-2.5 px-3 text-center w-16">Absen</th>
              <th className="py-2.5 px-3">Nama Lengkap</th>
              <th className="py-2.5 px-3 text-center w-28">Aksi</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filteredStudents.map((std) => {
              const isEditingThis = editingId === std.id;

              if (isEditingThis) {
                return (
                  <tr key={std.id} className="bg-teal-50/60">
                    <td className="py-2 px-3 text-center">
                      <input
                        type="number"
                        min="1"
                        value={absenInput}
                        onChange={(e) => setAbsenInput(e.target.value)}
                        className="w-12 text-center py-1 px-1 border border-teal-300 rounded bg-white text-xs font-bold"
                        required
                      />
                    </td>
                    <td className="py-2 px-3">
                      <input
                        type="text"
                        value={nameInput}
                        onChange={(e) => setNameInput(e.target.value)}
                        className="w-full py-1 px-2 border border-teal-300 rounded bg-white text-xs uppercase font-medium"
                        required
                        autoFocus
                      />
                    </td>
                    <td className="py-2 px-3 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={handleSaveEdit}
                          className="p-1 rounded bg-teal-700 text-white hover:bg-teal-800"
                          title="Simpan Perubahan"
                        >
                          <Check className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setEditingId(null)}
                          className="p-1 rounded bg-slate-200 text-slate-700 hover:bg-slate-300"
                          title="Batal"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              }

              return (
                <tr key={std.id} className="hover:bg-slate-50 transition">
                  <td className="py-2.5 px-3 text-center font-bold text-slate-600">
                    #{std.absen}
                  </td>
                  <td className="py-2.5 px-3 font-semibold text-slate-800">
                    {std.name}
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    <div className="flex items-center justify-center gap-1">
                      <button
                        onClick={() => handleStartEdit(std)}
                        className="p-1 text-slate-500 hover:text-teal-700 hover:bg-teal-50 rounded-lg transition"
                        title="Edit Siswa"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDelete(std)}
                        className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition"
                        title="Hapus Siswa"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
