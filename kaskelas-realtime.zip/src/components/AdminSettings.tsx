import React, { useState } from 'react';
import { Settings, Save, KeyRound, RotateCcw, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { AppData } from '../types';
import { formatRupiah } from '../utils/format';
import { apiUpdateSettings, apiResetData } from '../api';

interface AdminSettingsProps {
  data: AppData;
  onDataUpdated: (newData: AppData) => void;
}

export const AdminSettings: React.FC<AdminSettingsProps> = ({ data, onDataUpdated }) => {
  const [nominalInput, setNominalInput] = useState(String(data.nominalPerSession));
  const [pinInput, setPinInput] = useState(data.adminPin);
  const [isSaving, setIsSaving] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setMessage(null);

    const parsedNominal = parseInt(nominalInput, 10);
    if (isNaN(parsedNominal) || parsedNominal < 500) {
      setMessage({ type: 'error', text: 'Nominal kas per sesi minimal Rp 500.' });
      return;
    }

    if (!pinInput.trim() || pinInput.trim().length < 4) {
      setMessage({ type: 'error', text: 'PIN Bendahara minimal 4 karakter.' });
      return;
    }

    setIsSaving(true);
    try {
      const updated = await apiUpdateSettings(parsedNominal, pinInput.trim());
      onDataUpdated(updated);
      setMessage({ type: 'success', text: 'Pengaturan kas dan PIN berhasil disimpan!' });
    } catch (err: unknown) {
      setMessage({ type: 'error', text: err instanceof Error ? err.message : 'Gagal menyimpan pengaturan' });
    } finally {
      setIsSaving(false);
    }
  };

  const handleResetData = async () => {
    if (!confirm('PERINGATAN: Apakah Anda yakin ingin mengembalikan semua data ke 31 siswa awal default? Tindakan ini akan menghapus checklist tambahan.')) {
      return;
    }

    try {
      const updated = await apiResetData();
      onDataUpdated(updated);
      setNominalInput(String(updated.nominalPerSession));
      setPinInput(updated.adminPin);
      setMessage({ type: 'success', text: 'Data berhasil direset ke kondisi awal 31 siswa.' });
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="max-w-2xl mx-auto bg-white rounded-2xl p-5 sm:p-6 shadow-xs border border-slate-200 space-y-5">
      <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
        <Settings className="w-5 h-5 text-teal-700" />
        <div>
          <h3 className="font-bold text-slate-800 text-sm sm:text-base">Pengaturan Sistem Kas Kelas</h3>
          <p className="text-xs text-slate-500">Konfigurasi nominal penarikan kas dan kata sandi Bendahara</p>
        </div>
      </div>

      {message && (
        <div
          className={`p-3 rounded-xl text-xs flex items-center gap-2 ${
            message.type === 'success'
              ? 'bg-emerald-50 border border-emerald-200 text-emerald-800'
              : 'bg-rose-50 border border-rose-200 text-rose-800'
          }`}
        >
          {message.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
          ) : (
            <AlertTriangle className="w-4 h-4 shrink-0 text-rose-600" />
          )}
          <span>{message.text}</span>
        </div>
      )}

      <form onSubmit={handleSave} className="space-y-4 text-xs">
        {/* Nominal Kas per Session */}
        <div>
          <label className="block font-semibold text-slate-700 mb-1">
            Nominal Kas per Sesi Bayar (Rabu & Kamis)
          </label>
          <div className="relative">
            <span className="absolute left-3 top-2.5 font-bold text-slate-400">Rp</span>
            <input
              type="number"
              step="500"
              min="500"
              value={nominalInput}
              onChange={(e) => setNominalInput(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-sm font-bold border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-600 bg-white"
              required
            />
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            Default: <strong>Rp 2.000</strong> per sesi bayar. Dengan 2x penarikan (Rabu & Kamis), total per siswa per minggu adalah {formatRupiah(parseInt(nominalInput || '0', 10) * 2)}.
          </p>
        </div>

        {/* PIN Bendahara */}
        <div>
          <label className="block font-semibold text-slate-700 mb-1">
            PIN Keamanan Bendahara
          </label>
          <div className="relative">
            <KeyRound className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              value={pinInput}
              onChange={(e) => setPinInput(e.target.value)}
              placeholder="Contoh: 1234"
              className="w-full pl-9 pr-3 py-2 text-sm tracking-widest font-bold border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-600 bg-white"
              required
            />
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            PIN ini digunakan untuk membuka panel admin bendahara. Default: 1234.
          </p>
        </div>

        <button
          type="submit"
          disabled={isSaving}
          className="w-full py-2.5 bg-teal-700 hover:bg-teal-800 text-white font-bold rounded-xl shadow-xs transition flex items-center justify-center gap-2 text-sm"
        >
          <Save className="w-4 h-4" />
          <span>{isSaving ? 'Menyimpan...' : 'Simpan Perubahan'}</span>
        </button>
      </form>

      {/* Danger Zone: Reset Data */}
      <div className="pt-4 border-t border-slate-200">
        <h4 className="font-bold text-xs text-rose-800 mb-1 flex items-center gap-1.5">
          <RotateCcw className="w-4 h-4 text-rose-600" />
          Reset Data Awal
        </h4>
        <p className="text-[11px] text-slate-500 mb-2">
          Kembalikan data ke awal dengan 31 siswa lengkap dan saldo demo.
        </p>
        <button
          type="button"
          onClick={handleResetData}
          className="px-3 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-xl text-xs font-semibold transition"
        >
          Reset Data ke Default Awal
        </button>
      </div>
    </div>
  );
};
