import React, { useState } from 'react';
import { 
  Check, 
  X, 
  Search, 
  Plus, 
  Calendar, 
  CheckSquare, 
  Sparkles, 
  Clock, 
  Trash2,
  AlertCircle
} from 'lucide-react';
import { AppData, Student } from '../types';
import { formatRupiah } from '../utils/format';
import { apiTogglePayment, apiBulkTogglePayment, apiAddWeek, apiDeleteWeek } from '../api';

interface AdminChecklistProps {
  data: AppData;
  onDataUpdated: (newData: AppData) => void;
}

export const AdminChecklist: React.FC<AdminChecklistProps> = ({ data, onDataUpdated }) => {
  const [selectedWeekId, setSelectedWeekId] = useState<string>(data.weeks[0]?.id || 'w1');
  const [searchQuery, setSearchQuery] = useState('');
  const [isAddingWeek, setIsAddingWeek] = useState(false);
  const [newWeekLabel, setNewWeekLabel] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  const activeWeek = data.weeks.find((w) => w.id === selectedWeekId) || data.weeks[0];

  const filteredStudents = data.students.filter(
    (s) =>
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      String(s.absen).includes(searchQuery)
  );

  // Stats for current week
  let rabuPaidCount = 0;
  let kamisPaidCount = 0;
  data.students.forEach((s) => {
    const wp = data.payments[s.id]?.[selectedWeekId];
    if (wp?.rabu) rabuPaidCount++;
    if (wp?.kamis) kamisPaidCount++;
  });
  const totalStudents = data.students.length;
  const collectedWeek = (rabuPaidCount + kamisPaidCount) * data.nominalPerSession;

  const handleToggle = async (studentId: string, session: 'rabu' | 'kamis', currentVal: boolean) => {
    try {
      const updated = await apiTogglePayment(studentId, selectedWeekId, session, !currentVal);
      onDataUpdated(updated);
    } catch (err) {
      console.error(err);
    }
  };

  const handleBulkToggle = async (session?: 'rabu' | 'kamis', studentId?: string, paid: boolean = true) => {
    setIsSaving(true);
    try {
      const updated = await apiBulkTogglePayment({
        weekId: selectedWeekId,
        session,
        studentId,
        paid
      });
      onDataUpdated(updated);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSaving(false);
    }
  };

  const handleAddWeekSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newWeekLabel.trim()) return;
    try {
      const updated = await apiAddWeek(newWeekLabel.trim());
      onDataUpdated(updated);
      const newlyAdded = updated.weeks[updated.weeks.length - 1];
      if (newlyAdded) setSelectedWeekId(newlyAdded.id);
      setIsAddingWeek(false);
      setNewWeekLabel('');
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteWeek = async (weekId: string) => {
    if (!confirm('Yakin ingin menghapus minggu kas ini?')) return;
    try {
      const updated = await apiDeleteWeek(weekId);
      onDataUpdated(updated);
      if (selectedWeekId === weekId) {
        setSelectedWeekId(updated.weeks[0]?.id || '');
      }
    } catch (err: unknown) {
      alert(err instanceof Error ? err.message : 'Gagal menghapus');
    }
  };

  return (
    <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-xs border border-slate-200 space-y-4">
      {/* Week Selector Bar & Quick Stats */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pb-3 border-b border-slate-100">
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1.5 overflow-x-auto max-w-full pb-1 sm:pb-0">
            {data.weeks.map((week) => (
              <button
                key={week.id}
                onClick={() => setSelectedWeekId(week.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition ${
                  selectedWeekId === week.id
                    ? 'bg-teal-700 text-white shadow-xs'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                {week.label}
              </button>
            ))}
          </div>

          <button
            onClick={() => setIsAddingWeek(true)}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-bold bg-teal-50 text-teal-800 hover:bg-teal-100 border border-teal-200 transition"
          >
            <Plus className="w-3.5 h-3.5" />
            Tambah Minggu
          </button>
        </div>

        {/* Current Week Summary */}
        <div className="flex items-center gap-3 text-xs bg-slate-50 px-3 py-2 rounded-xl border border-slate-200">
          <div>
            <span className="text-slate-400">Kas Terkumpul Minggu Ini:</span>{' '}
            <strong className="text-teal-900 font-black">{formatRupiah(collectedWeek)}</strong>
          </div>
          <div className="hidden sm:block text-slate-300">|</div>
          <div className="hidden sm:flex items-center gap-2">
            <span>Rabu: <b className="text-teal-700">{rabuPaidCount}/{totalStudents}</b></span>
            <span>Kamis: <b className="text-teal-700">{kamisPaidCount}/{totalStudents}</b></span>
          </div>
        </div>
      </div>

      {/* Add Week Modal / Form */}
      {isAddingWeek && (
        <form onSubmit={handleAddWeekSubmit} className="p-3 bg-teal-50 border border-teal-200 rounded-xl flex flex-wrap items-center gap-2">
          <input
            type="text"
            value={newWeekLabel}
            onChange={(e) => setNewWeekLabel(e.target.value)}
            placeholder={`Contoh: Minggu ${data.weeks.length + 1} (November)`}
            className="flex-1 min-w-[200px] text-xs px-3 py-2 border border-teal-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-teal-600"
            autoFocus
            required
          />
          <button
            type="submit"
            className="px-3 py-2 bg-teal-700 text-white text-xs font-bold rounded-lg hover:bg-teal-800"
          >
            Simpan Minggu Baru
          </button>
          <button
            type="button"
            onClick={() => setIsAddingWeek(false)}
            className="px-3 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900"
          >
            Batal
          </button>
        </form>
      )}

      {/* Search & Bulk Action Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
        <div className="relative flex-1 sm:max-w-xs">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cari siswa atau absen..."
            className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-600 bg-white"
          />
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          <span className="text-[11px] text-slate-400 font-semibold mr-1">Aksi Cepat:</span>
          <button
            onClick={() => handleBulkToggle('rabu', undefined, true)}
            disabled={isSaving}
            className="px-2.5 py-1 text-[11px] font-bold rounded-lg bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-300 transition"
          >
            Centang Semua Rabu
          </button>
          <button
            onClick={() => handleBulkToggle('kamis', undefined, true)}
            disabled={isSaving}
            className="px-2.5 py-1 text-[11px] font-bold rounded-lg bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-300 transition"
          >
            Centang Semua Kamis
          </button>
          {data.weeks.length > 1 && (
            <button
              onClick={() => handleDeleteWeek(selectedWeekId)}
              className="p-1 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition"
              title="Hapus minggu ini"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Main Checklist Table */}
      <div className="overflow-x-auto border border-slate-200 rounded-xl shadow-xs">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
            <tr>
              <th className="py-2.5 px-3 text-center w-12">Absen</th>
              <th className="py-2.5 px-3">Nama Lengkap Siswa</th>
              <th className="py-2.5 px-3 text-center w-36">
                <div className="font-extrabold text-teal-900">Sesi Rabu</div>
                <div className="text-[10px] font-normal text-slate-500">Rp {data.nominalPerSession.toLocaleString('id-ID')}</div>
              </th>
              <th className="py-2.5 px-3 text-center w-36">
                <div className="font-extrabold text-teal-900">Sesi Kamis</div>
                <div className="text-[10px] font-normal text-slate-500">Rp {data.nominalPerSession.toLocaleString('id-ID')}</div>
              </th>
              <th className="py-2.5 px-3 text-center w-28">Status Minggu</th>
              <th className="py-2.5 px-3 text-center w-28">Aksi Cepat</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filteredStudents.map((student) => {
              const weekPayment = data.payments[student.id]?.[selectedWeekId] || {
                rabu: false,
                kamis: false
              };
              const isWeekLunas = weekPayment.rabu && weekPayment.kamis;

              return (
                <tr
                  key={student.id}
                  className={`hover:bg-slate-50 transition ${
                    isWeekLunas ? 'bg-emerald-50/20' : ''
                  }`}
                >
                  <td className="py-2.5 px-3 text-center font-bold text-slate-600">
                    #{student.absen}
                  </td>
                  <td className="py-2.5 px-3">
                    <span className="font-semibold text-slate-800">{student.name}</span>
                  </td>

                  {/* Checklist Sesi Rabu */}
                  <td className="py-2.5 px-3 text-center">
                    <label className="inline-flex items-center gap-2 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={weekPayment.rabu}
                        onChange={() => handleToggle(student.id, 'rabu', weekPayment.rabu)}
                        className="w-4 h-4 text-teal-600 rounded border-slate-300 focus:ring-teal-500 cursor-pointer"
                      />
                      <span
                        className={`text-[11px] font-bold ${
                          weekPayment.rabu ? 'text-emerald-700' : 'text-slate-400'
                        }`}
                      >
                        {weekPayment.rabu ? 'Lunas' : 'Belum'}
                      </span>
                    </label>
                  </td>

                  {/* Checklist Sesi Kamis */}
                  <td className="py-2.5 px-3 text-center">
                    <label className="inline-flex items-center gap-2 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={weekPayment.kamis}
                        onChange={() => handleToggle(student.id, 'kamis', weekPayment.kamis)}
                        className="w-4 h-4 text-teal-600 rounded border-slate-300 focus:ring-teal-500 cursor-pointer"
                      />
                      <span
                        className={`text-[11px] font-bold ${
                          weekPayment.kamis ? 'text-emerald-700' : 'text-slate-400'
                        }`}
                      >
                        {weekPayment.kamis ? 'Lunas' : 'Belum'}
                      </span>
                    </label>
                  </td>

                  {/* Status Minggu Ini */}
                  <td className="py-2.5 px-3 text-center">
                    {isWeekLunas ? (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                        Lunas
                      </span>
                    ) : weekPayment.rabu || weekPayment.kamis ? (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900">
                        1/2 Lunas
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800">
                        Belum Bayar
                      </span>
                    )}
                  </td>

                  {/* Aksi Cepat: Lunas 1 Minggu */}
                  <td className="py-2.5 px-3 text-center">
                    {isWeekLunas ? (
                      <button
                        onClick={() => handleBulkToggle(undefined, student.id, false)}
                        className="text-[10px] font-semibold text-slate-400 hover:text-rose-600 underline"
                      >
                        Batalkan
                      </button>
                    ) : (
                      <button
                        onClick={() => handleBulkToggle(undefined, student.id, true)}
                        className="px-2 py-1 text-[10px] font-bold rounded-lg bg-teal-50 hover:bg-teal-100 text-teal-800 border border-teal-200 transition"
                      >
                        Set Lunas
                      </button>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
        <span>Menampilkan {filteredStudents.length} dari {data.students.length} siswa</span>
        <span>Perubahan checklist otomatis tersimpan dan terkirim secara realtime</span>
      </div>
    </div>
  );
};
