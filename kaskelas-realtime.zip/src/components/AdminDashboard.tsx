import React, { useState } from 'react';
import { 
  CheckSquare, 
  AlertTriangle, 
  ShoppingBag, 
  Bell, 
  Users, 
  Settings, 
  Coins, 
  TrendingUp, 
  TrendingDown, 
  ShieldCheck,
  CheckCircle2,
  Calendar
} from 'lucide-react';
import { AppData, Student } from '../types';
import { formatRupiah, calculateSummary } from '../utils/format';
import { AdminChecklist } from './AdminChecklist';
import { AdminDebtors } from './AdminDebtors';
import { AdminExpenses } from './AdminExpenses';
import { AdminNotifications } from './AdminNotifications';
import { AdminMembers } from './AdminMembers';
import { AdminSettings } from './AdminSettings';

interface AdminDashboardProps {
  data: AppData;
  onDataUpdated: (newData: AppData) => void;
  onLogout: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  data,
  onDataUpdated,
  onLogout
}) => {
  const [activeTab, setActiveTab] = useState<
    'checklist' | 'debtors' | 'expenses' | 'notifications' | 'members' | 'settings'
  >('checklist');

  // Pre-fill fields when transferring from Debtors to Notifications
  const [prefilledStudentId, setPrefilledStudentId] = useState<string>('all');
  const [prefilledMessage, setPrefilledMessage] = useState<string>('');

  const summary = calculateSummary(data);

  const handlePrepareNotification = (studentId: string, message: string) => {
    setPrefilledStudentId(studentId);
    setPrefilledMessage(message);
    setActiveTab('notifications');
  };

  return (
    <div className="space-y-4 pb-12">
      {/* Admin Top Header Banner */}
      <div className="bg-gradient-to-r from-teal-900 via-teal-800 to-slate-900 text-white rounded-2xl p-4 sm:p-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 relative z-10">
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-400/20 text-amber-300 text-xs font-bold mb-2 border border-amber-400/30">
              <ShieldCheck className="w-4 h-4 text-amber-300" />
              Panel Bendahara Kelas
            </div>
            <h2 className="text-xl sm:text-2xl font-black tracking-tight">
              Manajemen & Rekap Kas Kelas
            </h2>
            <p className="text-xs sm:text-sm text-teal-200 mt-0.5">
              Jadwal Penarikan: Setiap <strong className="text-white">Rabu & Kamis</strong> &bull; Nominal: <strong className="text-amber-300">{formatRupiah(data.nominalPerSession)}</strong> per sesi
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="px-3 py-1.5 rounded-xl bg-teal-800/80 border border-teal-600/50 text-xs font-semibold text-teal-100">
              {data.students.length} Siswa Terdaftar
            </span>
          </div>
        </div>
      </div>

      {/* Top 4 Financial & Ledger Overview Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-white p-3.5 sm:p-4 rounded-2xl shadow-xs border border-slate-200 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-bold uppercase tracking-wide">Saldo Kas Aktif</span>
            <div className="w-7 h-7 rounded-lg bg-teal-50 text-teal-700 flex items-center justify-center">
              <Coins className="w-4 h-4" />
            </div>
          </div>
          <div className="text-base sm:text-xl font-black text-teal-900 truncate">
            {formatRupiah(summary.activeBalance)}
          </div>
          <span className="text-[10px] text-teal-600 mt-1 font-medium">Uang kas bersih siap pakai</span>
        </div>

        <div className="bg-white p-3.5 sm:p-4 rounded-2xl shadow-xs border border-slate-200 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-bold uppercase tracking-wide">Total Pemasukan</span>
            <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="text-base sm:text-xl font-black text-emerald-700 truncate">
            {formatRupiah(summary.totalIncome)}
          </div>
          <span className="text-[10px] text-emerald-600 mt-1 font-medium">Dari {summary.totalCheckedSessions} sesi terbayar</span>
        </div>

        <div className="bg-white p-3.5 sm:p-4 rounded-2xl shadow-xs border border-slate-200 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-bold uppercase tracking-wide">Total Pengeluaran</span>
            <div className="w-7 h-7 rounded-lg bg-rose-50 text-rose-700 flex items-center justify-center">
              <TrendingDown className="w-4 h-4" />
            </div>
          </div>
          <div className="text-base sm:text-xl font-black text-rose-700 truncate">
            {formatRupiah(summary.totalExpense)}
          </div>
          <span className="text-[10px] text-rose-600 mt-1 font-medium">{data.expenses.length} transaksi belanja</span>
        </div>

        <div className="bg-white p-3.5 sm:p-4 rounded-2xl shadow-xs border border-slate-200 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-bold uppercase tracking-wide">Rekap Penunggak</span>
            <div className="w-7 h-7 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="text-base sm:text-xl font-black text-amber-900 truncate">
            {summary.debtors.length} Siswa
          </div>
          <span className="text-[10px] text-amber-700 mt-1 font-medium">{summary.lunasCount} siswa telah lunas</span>
        </div>
      </div>

      {/* Main Admin Tab Navigation Bar */}
      <div className="bg-slate-200/80 p-1 rounded-xl flex gap-1 overflow-x-auto text-xs font-bold text-slate-600">
        <button
          onClick={() => setActiveTab('checklist')}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-lg whitespace-nowrap transition ${
            activeTab === 'checklist'
              ? 'bg-white text-teal-900 shadow-xs'
              : 'hover:text-slate-900'
          }`}
        >
          <CheckSquare className="w-3.5 h-3.5" />
          Pencatatan Kas (Checklist)
        </button>

        <button
          onClick={() => setActiveTab('debtors')}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-lg whitespace-nowrap transition relative ${
            activeTab === 'debtors'
              ? 'bg-white text-teal-900 shadow-xs'
              : 'hover:text-slate-900'
          }`}
        >
          <AlertTriangle className="w-3.5 h-3.5" />
          Rekap Penunggak
          {summary.debtors.length > 0 && (
            <span className="bg-rose-600 text-white text-[10px] font-bold px-1.5 py-0.2 rounded-full">
              {summary.debtors.length}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('expenses')}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-lg whitespace-nowrap transition ${
            activeTab === 'expenses'
              ? 'bg-white text-teal-900 shadow-xs'
              : 'hover:text-slate-900'
          }`}
        >
          <ShoppingBag className="w-3.5 h-3.5" />
          Pengeluaran & Belanja
        </button>

        <button
          onClick={() => setActiveTab('notifications')}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-lg whitespace-nowrap transition ${
            activeTab === 'notifications'
              ? 'bg-white text-teal-900 shadow-xs'
              : 'hover:text-slate-900'
          }`}
        >
          <Bell className="w-3.5 h-3.5" />
          Kirim Notifikasi Realtime
        </button>

        <button
          onClick={() => setActiveTab('members')}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-lg whitespace-nowrap transition ${
            activeTab === 'members'
              ? 'bg-white text-teal-900 shadow-xs'
              : 'hover:text-slate-900'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          Manajemen Anggota ({data.students.length})
        </button>

        <button
          onClick={() => setActiveTab('settings')}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-lg whitespace-nowrap transition ${
            activeTab === 'settings'
              ? 'bg-white text-teal-900 shadow-xs'
              : 'hover:text-slate-900'
          }`}
        >
          <Settings className="w-3.5 h-3.5" />
          Pengaturan Kas
        </button>
      </div>

      {/* Render Selected Tab */}
      {activeTab === 'checklist' && (
        <AdminChecklist data={data} onDataUpdated={onDataUpdated} />
      )}

      {activeTab === 'debtors' && (
        <AdminDebtors data={data} onPrepareNotification={handlePrepareNotification} />
      )}

      {activeTab === 'expenses' && (
        <AdminExpenses data={data} onDataUpdated={onDataUpdated} />
      )}

      {activeTab === 'notifications' && (
        <AdminNotifications
          data={data}
          onDataUpdated={onDataUpdated}
          prefilledStudentId={prefilledStudentId}
          prefilledMessage={prefilledMessage}
        />
      )}

      {activeTab === 'members' && (
        <AdminMembers data={data} onDataUpdated={onDataUpdated} />
      )}

      {activeTab === 'settings' && (
        <AdminSettings data={data} onDataUpdated={onDataUpdated} />
      )}
    </div>
  );
};
