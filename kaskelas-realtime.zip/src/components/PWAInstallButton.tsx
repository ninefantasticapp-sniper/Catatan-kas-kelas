import React, { useState } from 'react';
import { Download, Smartphone, X } from 'lucide-react';
import { usePWAInstall } from './usePWAInstall';

export const PWAInstallButton: React.FC<{ variant?: 'header' | 'banner' }> = ({ variant = 'header' }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  // If already running as an installed PWA, hide the button
  if (isInstalled) {
    return null;
  }

  // Chromium / Android / Desktop flow
  if (isInstallable) {
    if (variant === 'banner') {
      return (
        <div className="flex items-center justify-between gap-3 p-3 bg-teal-50 border border-teal-200 rounded-xl text-teal-900 text-xs sm:text-sm">
          <div className="flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-teal-700 shrink-0" />
            <span>Pasang aplikasi di layar utama HP untuk notifikasi bilah status lebih optimal.</span>
          </div>
          <button
            onClick={install}
            className="flex items-center gap-1.5 shrink-0 bg-teal-700 hover:bg-teal-800 text-white font-medium px-3 py-1.5 rounded-lg shadow-sm transition"
          >
            <Download className="w-3.5 h-3.5" />
            Install App
          </button>
        </div>
      );
    }

    return (
      <button
        onClick={install}
        className="flex items-center gap-1.5 rounded-lg bg-teal-600 px-3 py-1.5 text-xs font-semibold text-white shadow-sm hover:bg-teal-700 active:scale-95 transition"
        title="Pasang aplikasi di HP"
      >
        <Download className="w-3.5 h-3.5" />
        <span>Install PWA</span>
      </button>
    );
  }

  // iOS Safari flow
  if (isIOS) {
    return (
      <>
        <button
          onClick={() => setShowIOSGuide(true)}
          className="flex items-center gap-1.5 rounded-lg border border-teal-300 bg-white/80 px-2.5 py-1 text-xs font-medium text-teal-800 hover:bg-white shadow-xs"
        >
          <Smartphone className="w-3.5 h-3.5" />
          <span>Pasang di iOS</span>
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-fade-in">
            <div className="w-full max-w-sm rounded-2xl bg-white p-5 shadow-2xl text-slate-800">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <h3 className="text-base font-bold text-teal-900 flex items-center gap-2">
                  <Smartphone className="w-5 h-5 text-teal-600" />
                  Pasang di iPhone / iPad
                </h3>
                <button
                  onClick={() => setShowIOSGuide(false)}
                  className="text-slate-400 hover:text-slate-600 p-1"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <ol className="mt-3 text-xs sm:text-sm text-slate-600 space-y-2 list-decimal list-inside leading-relaxed">
                <li>Buka situs ini di browser Safari.</li>
                <li>Tekan tombol <strong>Bagikan (Share)</strong> di bilah bawah.</li>
                <li>Pilih <strong>Tambahkan ke Layar Utama (Add to Home Screen)</strong>.</li>
                <li>Aplikasi akan muncul seperti aplikasi HP asli dengan ikon Kas Kelas.</li>
              </ol>
              <button
                onClick={() => setShowIOSGuide(false)}
                className="mt-4 w-full rounded-xl bg-teal-600 py-2.5 text-xs sm:text-sm font-semibold text-white hover:bg-teal-700 shadow-sm"
              >
                Saya Mengerti
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};
