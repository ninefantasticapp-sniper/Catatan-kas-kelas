import { AppData, Student } from './types';

export const INITIAL_STUDENTS_LIST: string[] = [
  "AFFLAH INTAN NOOR IZZAH",
  "AHMAD RENO KHOIDOR MAULANA",
  "AMELIA AYU SAFIRA",
  "ANGGUN KHAIRUNNISA AZZAHRA",
  "ARIFFI KHOIRUN NIZAR",
  "ATHALIA WIDYA PRAMESWARI",
  "AYU NOVITA DIUSTIRA",
  "BISMA NARAENDRA AZKA LAKSANA",
  "CALLISTA MICHEILS NATHANIA",
  "CYNTHA LIALATUL QUR'AN",
  "DEVARA RAKHA ADWIJAYA",
  "DHIA AULIA NUR MAKAILA",
  "DINI ANGGRAINI",
  "FAIRIS ZALFA HERDIANI",
  "FIRMAN MAULANA PUTRA",
  "GHISTA FELIYANA FAIRIN",
  "IBNU SAWQISYAH",
  "JULIA PRICILIA TUNGGAL DEWI",
  "M. RAFY HANIF ASLAM",
  "MOCH ARIEF RAHMAN HAKIM",
  "MUHAMMAD CAESAR FAHREZY",
  "MUHAMMAD NAUFAL PUTRA RADITYA",
  "MUHAMMAD RIZAL TRISANTOSO",
  "NAFITA DWI LESTARI",
  "NINDIYA CALLISTA PRIMALIA SARI",
  "PRADANA RAHADIAN NUGROHO",
  "QANIAH SHAKIRAH PULUNGAN",
  "SATRIO ANDI BRAMANTIO",
  "SAZKIA AULIA PUTRI",
  "YANUARTA AINUN NADZAR",
  "YULIANA NUR CAHYA"
];

export const INITIAL_STUDENTS: Student[] = INITIAL_STUDENTS_LIST.map((name, index) => ({
  id: `std-${index + 1}`,
  name,
  absen: index + 1
}));

export const INITIAL_WEEKS = [
  { id: 'w1', label: 'Minggu 1 (Bulan Berjalan)' },
  { id: 'w2', label: 'Minggu 2 (Bulan Berjalan)' },
  { id: 'w3', label: 'Minggu 3 (Bulan Berjalan)' },
  { id: 'w4', label: 'Minggu 4 (Bulan Berjalan)' }
];

export function getInitialData(): AppData {
  const payments: AppData['payments'] = {};

  INITIAL_STUDENTS.forEach((std) => {
    payments[std.id] = {
      w1: { rabu: true, kamis: true, rabuPaidAt: '2026-10-01', kamisPaidAt: '2026-10-02' },
      w2: { 
        rabu: std.absen % 3 !== 0, 
        kamis: std.absen % 4 !== 0,
        rabuPaidAt: std.absen % 3 !== 0 ? '2026-10-08' : undefined,
        kamisPaidAt: std.absen % 4 !== 0 ? '2026-10-09' : undefined
      },
      w3: { 
        rabu: std.absen <= 20, 
        kamis: std.absen <= 15,
        rabuPaidAt: std.absen <= 20 ? '2026-10-15' : undefined,
        kamisPaidAt: std.absen <= 15 ? '2026-10-16' : undefined
      },
      w4: { 
        rabu: false, 
        kamis: false 
      }
    };
  });

  return {
    nominalPerSession: 2000,
    adminPin: '1234',
    students: INITIAL_STUDENTS,
    weeks: INITIAL_WEEKS,
    payments,
    expenses: [
      {
        id: 'exp-1',
        date: '2026-10-03',
        title: 'Spidol Whiteboard & Refill Tinta',
        amount: 25000,
        category: 'ATK',
        note: 'Beli di fotokopi depan sekolah untuk kelas',
        createdAt: Date.now() - 86400000 * 8
      },
      {
        id: 'exp-2',
        date: '2026-10-06',
        title: 'Alat Kebersihan (Sapu & Trash Bag)',
        amount: 32000,
        category: 'Kebersihan',
        note: 'Sapu ijuk baru dan kantong plastik piket',
        createdAt: Date.now() - 86400000 * 5
      },
      {
        id: 'exp-3',
        date: '2026-10-10',
        title: 'Uang Kas Sosial (Jenguk Teman Sakit)',
        amount: 50000,
        category: 'Sosial',
        note: 'Buah dan bingkisan untuk teman yang dirawat',
        createdAt: Date.now() - 86400000 * 2
      }
    ],
    notifications: [
      {
        id: 'notif-init-1',
        targetStudentId: 'all',
        title: 'Pengingat Kas Kelas',
        message: 'Halo semua! Jangan lupa kas ditarik setiap hari Rabu & Kamis sebesar Rp 2.000 per sesi. Mohon siapkan uang pas ya.',
        createdAt: Date.now() - 86400000 * 3,
        readBy: []
      }
    ],
    lastUpdated: Date.now()
  };
}
